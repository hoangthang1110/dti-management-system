<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\DtiCategory;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Collection; // Import Collection

class DtiCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        // Kiểm tra quyền truy cập 'configure indicators'
        $this->authorize('configure indicators');

        $sortField = $request->query('sort', 'order_column'); // Mặc định sắp xếp theo order_column
        $sortDirection = $request->query('direction', 'asc'); // Mặc định sắp xếp tăng dần

        // Đảm bảo chỉ sắp xếp theo các trường hợp lệ
        if (!in_array($sortField, ['id', 'name', 'order_column'])) {
            $sortField = 'order_column';
        }
        if (!in_array($sortDirection, ['asc', 'desc'])) {
            $sortDirection = 'asc';
        }

        // Lấy tất cả danh mục, eager load quan hệ 'parent' và phân trang
        $categories = DtiCategory::with('parent')
                                ->orderBy($sortField, $sortDirection)
                                ->paginate(10);

        return view('admin.dti-categories.index', compact('categories', 'sortField', 'sortDirection'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        // Kiểm tra quyền truy cập 'configure indicators'
        $this->authorize('configure indicators');

        // Lấy tất cả các danh mục để làm danh mục cha, eager load children đệ quy
        $allCategories = DtiCategory::whereNull('parent_id')
                                ->with('children') // Tải quan hệ con
                                ->orderBy('order_column')
                                ->get();

        $parentCategories = $this->getFormattedCategoriesForDropdown($allCategories);

        return view('admin.dti-categories.create', compact('parentCategories'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request): RedirectResponse
    {
        // Kiểm tra quyền truy cập 'configure indicators'
        $this->authorize('configure indicators');

        $request->validate([
            'name' => [
                'required',
                'string',
                'max:255',
                Rule::unique(DtiCategory::class),
            ],
            'description' => 'nullable|string',
            'parent_id' => 'nullable|exists:dti_categories,id', // Thêm validation cho parent_id
        ], [
            'name.required' => 'Tên danh mục là bắt buộc.',
            'name.unique' => 'Tên danh mục này đã tồn tại.',
            'name.max' => 'Tên danh mục không được vượt quá 255 ký tự.',
            'parent_id.exists' => 'Danh mục cha không hợp lệ.', // Custom message
        ]);

        $newCategory = DtiCategory::create($request->all());

        // Xây dựng thông báo thành công tùy chỉnh
        $message = '';
        if ($newCategory->parent_id) {
            $parentName = DtiCategory::find($newCategory->parent_id)->name ?? 'không xác định';
            $message = "Bạn đã thêm thành công danh mục '{$newCategory->name}' là con của danh mục '{$parentName}'.";
        } else {
            $message = "Bạn đã thêm thành công danh mục '{$newCategory->name}' cấp cao nhất.";
        }

        // Sau khi lưu thành công, redirect về lại trang create với cờ success
        // để JS trong create.blade.php có thể đóng tab và tải lại tab cha.
        return redirect()->route('admin.dti-categories.create')
                         ->with('status', 'success')
                         ->with('message', $message);
    }

    /**
     * Display the specified resource.
     */
    public function show(DtiCategory $dtiCategory)
    {
        // Kiểm tra quyền truy cập 'configure indicators'
        $this->authorize('configure indicators');

        return view('admin.dti-categories.show', compact('dtiCategory'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(DtiCategory $dtiCategory)
    {
        // Kiểm tra quyền truy cập 'configure indicators'
        $this->authorize('configure indicators');

        // Lấy tất cả các danh mục, eager load children đệ quy
        $allCategories = DtiCategory::whereNull('parent_id') // Bắt đầu từ cấp cao nhất
                                ->with('children')
                                ->orderBy('order_column')
                                ->get();

        // Tạo một collection rỗng để lưu các danh mục đã lọc
        $filteredCategories = new Collection();

        // Lọc ra chính danh mục đang sửa và các danh mục con của nó
        $this->filterAndBuildCategories(
            $allCategories,
            $dtiCategory,
            $filteredCategories
        );

        $parentCategories = $this->getFormattedCategoriesForDropdown($filteredCategories);

        return view('admin.dti-categories.edit', compact('dtiCategory', 'parentCategories'));
    }

    /**
     * Hàm trợ giúp đệ quy để lọc các danh mục (loại bỏ danh mục đang sửa và con cháu của nó).
     *
     * @param Collection $categories Nguồn danh mục để lọc.
     * @param DtiCategory $excludeCategory Danh mục cần loại trừ.
     * @param Collection $resultCollection Collection để thêm các danh mục đã lọc vào.
     */
    protected function filterAndBuildCategories(
        Collection $categories,
        DtiCategory $excludeCategory,
        Collection &$resultCollection
    ) {
        foreach ($categories as $category) {
            // Loại bỏ chính danh mục đang sửa hoặc nếu nó là con cháu của danh mục đang sửa
            if ($category->id === $excludeCategory->id || $category->isDescendantOf($excludeCategory->id)) {
                continue;
            }

            // Thêm danh mục vào kết quả
            $resultCollection->push($category);

            // Xử lý các danh mục con
            if ($category->children->isNotEmpty()) {
                $this->filterAndBuildCategories($category->children, $excludeCategory, $resultCollection);
            }
        }
    }


    /**
     * Hàm trợ giúp để xây dựng danh sách danh mục thụt lề cho dropdown.
     *
     * @param Collection $categories Collection các danh mục (đã được eager load children).
     * @param int $level Cấp độ hiện tại để thụt lề.
     * @param string $prefix Ký tự tiền tố cho mỗi cấp độ (ví dụ: '-').
     * @return array Danh sách danh mục đã định dạng.
     */
    protected function getFormattedCategoriesForDropdown(
        Collection $categories,
        int $level = 0,
        string $prefix = '--'
    ): array {
        $formattedList = [];
        foreach ($categories as $category) {
            $indent = $level > 0 ? str_repeat($prefix, $level) . ' ' : '';
            $formattedList[] = [
                'id' => $category->id,
                'name' => $indent . $category->name,
            ];

            if ($category->children->isNotEmpty()) {
                $formattedList = array_merge(
                    $formattedList,
                    $this->getFormattedCategoriesForDropdown($category->children, $level + 1, $prefix)
                );
            }
        }
        return $formattedList;
    }


    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, DtiCategory $dtiCategory)
    {
        // Kiểm tra quyền truy cập 'configure indicators'
        $this->authorize('configure indicators');

        $request->validate([
            'name' => [
                'required',
                'string',
                'max:255',
                Rule::unique('dti_categories')->ignore($dtiCategory->id),
            ],
            'description' => 'nullable|string',
            'parent_id' => [
                'nullable',
                'exists:dti_categories,id',
                // Quy tắc tùy chỉnh để ngăn danh mục tự làm cha cho chính nó hoặc con cháu của nó
                function ($attribute, $value, $fail) use ($dtiCategory) {
                    if ($value && $value == $dtiCategory->id) {
                        $fail('Danh mục cha không thể là chính nó.');
                    }
                    if ($value && $dtiCategory->isDescendantOf((int)$value)) { // Ép kiểu $value sang int
                        $fail('Danh mục cha không thể là một danh mục con của nó.');
                    }
                },
            ],
        ], [
            'name.required' => 'Tên danh mục là bắt buộc.',
            'name.unique' => 'Tên danh mục đã tồn tại.',
            'name.max' => 'Tên danh mục không được vượt quá 255 ký tự.',
            'parent_id.exists' => 'Danh mục cha không hợp lệ.',
        ]);

        $dtiCategory->update($request->all());

        return redirect()->route('admin.dti-categories.index')
                         ->with('success', 'Danh mục DTI đã được cập nhật thành công.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(DtiCategory $dtiCategory)
    {
        // Kiểm tra quyền truy cập 'configure indicators'
        $this->authorize('configure indicators');

        $dtiCategory->delete();

        return redirect()->route('admin.dti-categories.index')
                         ->with('success', 'Danh mục DTI đã được xóa thành công.');
    }

    /**
     * Update the order of resources.
     */
    public function updateOrder(Request $request)
    {
        // Kiểm tra quyền truy cập 'configure indicators'
        $this->authorize('configure indicators');

        $request->validate([
            'ids' => 'required|array',
            'ids.*' => 'integer|exists:dti_categories,id', // Đảm bảo các ID tồn tại
        ]);

        $ids = $request->input('ids');

        foreach ($ids as $index => $id) {
            DtiCategory::where('id', $id)->update(['order_column' => $index + 1]);
        }

        return response()->json(['message' => 'Thứ tự danh mục đã được cập nhật thành công.'], 200);
    }
}